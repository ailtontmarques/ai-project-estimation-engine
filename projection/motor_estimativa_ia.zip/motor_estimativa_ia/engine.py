"""Motor determinístico de estimativa de esforço e custo.

Uso:
  python engine.py --parameters parameters.json --project project_example.json
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from typing import Any


def load_json(path: str | Path) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def pert_hours(activity: dict[str, Any], parameters: dict[str, Any]) -> float:
    """Estimativa PERT: (O + 4*M + P) / 6, usando pesos configuráveis."""
    o = float(activity["optimistic_hours"])
    m = float(activity["most_likely_hours"])
    p = float(activity["pessimistic_hours"])
    if min(o, m, p) < 0:
        raise ValueError(f"Horas não podem ser negativas: {activity.get('id', activity.get('name'))}")
    if not (o <= m <= p):
        raise ValueError(f"Esperado otimista <= mais provável <= pessimista em {activity.get('id', activity.get('name'))}")
    cfg = parameters["pert"]
    divisor = float(cfg["divisor"])
    if divisor <= 0:
        raise ValueError("O divisor PERT precisa ser positivo.")
    return (o * float(cfg["optimistic_weight"]) +
            m * float(cfg["most_likely_weight"]) +
            p * float(cfg["pessimistic_weight"])) / divisor


def validate_allocations(allocations: dict[str, Any], activity_name: str, tolerance: float = 1e-6) -> None:
    if not allocations:
        raise ValueError(f"Atividade sem alocação de equipe: {activity_name}")
    total = 0.0
    for role, seniorities in allocations.items():
        if not isinstance(seniorities, dict) or not seniorities:
            raise ValueError(f"Alocação inválida para o papel {role} em {activity_name}")
        for seniority, share in seniorities.items():
            share = float(share)
            if share < 0 or share > 1:
                raise ValueError(f"Percentual deve estar entre 0 e 1: {activity_name}/{role}/{seniority}")
            total += share
    if abs(total - 1.0) > tolerance:
        raise ValueError(f"Alocações devem somar 100% em {activity_name}; total atual: {total:.4f}")


def iter_activities(project: dict[str, Any]):
    for feature in project.get("features", []):
        for task in feature.get("tasks", []):
            for activity in task.get("activities", []):
                yield feature, task, activity


def calculate_project(project: dict[str, Any], parameters: dict[str, Any]) -> dict[str, Any]:
    """Calcula baseline sem IA e cenário com IA, preservando custos por papel/senioridade."""
    rows = []
    role_hours: dict[str, float] = {}
    role_costs: dict[str, float] = {}
    base_hours_total = 0.0
    ai_hours_total = 0.0
    base_labor_cost = 0.0
    ai_labor_cost = 0.0
    ai_cfg = parameters["ai"]

    for feature, task, activity in iter_activities(project):
        name = f'{feature["name"]} / {task["name"]} / {activity["name"]}'
        validate_allocations(activity.get("allocations", {}), name)
        base_hours = pert_hours(activity, parameters)
        ai_cfg_activity = activity.get("ai", {})
        eligible_share = float(ai_cfg_activity.get("eligible_share", ai_cfg["eligible_share_default"]))
        reduction_rate = float(ai_cfg_activity.get("reduction_rate", ai_cfg["reduction_rate_default"]))
        review_ratio = float(ai_cfg_activity.get("review_hours_per_base_hour", ai_cfg["review_hours_per_base_hour_default"]))
        rework_ratio = float(ai_cfg_activity.get("rework_hours_per_base_hour", ai_cfg["rework_hours_per_base_hour_default"]))
        for key, val in [("eligible_share", eligible_share), ("reduction_rate", reduction_rate)]:
            if not 0 <= val <= 1:
                raise ValueError(f"{key} deve estar entre 0 e 1 em {name}")
        if review_ratio < 0 or rework_ratio < 0:
            raise ValueError(f"Revisão e retrabalho não podem ser negativos em {name}")

        ai_hours = base_hours * (1 - eligible_share * reduction_rate) + base_hours * review_ratio + base_hours * rework_ratio
        activity_base_cost = 0.0
        activity_ai_cost = 0.0
        allocation_rows = []
        for role, seniorities in activity["allocations"].items():
            for seniority, share in seniorities.items():
                try:
                    rate = float(parameters["roles"][role][seniority])
                except KeyError as exc:
                    raise ValueError(f"Taxa horária não configurada para {role}/{seniority}") from exc
                h_base = base_hours * float(share)
                h_ai = ai_hours * float(share)
                c_base = h_base * rate
                c_ai = h_ai * rate
                allocation_rows.append({
                    "role": role, "seniority": seniority, "share": float(share),
                    "hourly_rate": rate, "base_hours": h_base, "ai_hours": h_ai,
                    "base_labor_cost": c_base, "ai_labor_cost": c_ai
                })
                key = f"{role}/{seniority}"
                role_hours[key] = role_hours.get(key, 0.0) + h_base
                role_costs[key] = role_costs.get(key, 0.0) + c_base
                activity_base_cost += c_base
                activity_ai_cost += c_ai

        rows.append({
            "feature_id": feature["id"], "feature": feature["name"],
            "task_id": task["id"], "task": task["name"],
            "activity_id": activity["id"], "activity": activity["name"],
            "base_hours": base_hours, "ai_hours": ai_hours,
            "hours_saved": base_hours - ai_hours,
            "base_labor_cost": activity_base_cost, "ai_labor_cost": activity_ai_cost,
            "allocations": allocation_rows
        })
        base_hours_total += base_hours
        ai_hours_total += ai_hours
        base_labor_cost += activity_base_cost
        ai_labor_cost += activity_ai_cost

    contingency_rate = float(project.get("contingency_rate", parameters["contingency_rate_default"]))
    if not 0 <= contingency_rate <= 1:
        raise ValueError("A contingência deve estar entre 0 e 1.")
    ai_tooling_cost = float(ai_cfg.get("tooling_cost_brl_per_project", 0))
    base_contingency = base_labor_cost * contingency_rate
    ai_contingency = ai_labor_cost * contingency_rate
    base_total_cost = base_labor_cost + base_contingency
    ai_total_cost = ai_labor_cost + ai_contingency + ai_tooling_cost

    def money(n: float) -> float:
        return round(n, 2)
    def hours(n: float) -> float:
        return round(n, 2)

    return {
        "project_id": project.get("project_id"),
        "project_name": project.get("name"),
        "currency": parameters.get("currency", "BRL"),
        "assumptions": {
            "parameters_version": parameters.get("config_version", "unspecified"),
            "ai_eligible_share_default": ai_cfg["eligible_share_default"],
            "ai_reduction_rate_default": ai_cfg["reduction_rate_default"],
            "contingency_rate": contingency_rate,
            "note": "Parâmetros iniciais ilustrativos; substitua por dados calibrados da organização."
        },
        "summary": {
            "activity_count": len(rows),
            "base_hours": hours(base_hours_total),
            "ai_hours": hours(ai_hours_total),
            "hours_saved": hours(base_hours_total - ai_hours_total),
            "hours_saved_percent": round((base_hours_total-ai_hours_total)/base_hours_total*100, 2) if base_hours_total else 0,
            "base_labor_cost": money(base_labor_cost),
            "ai_labor_cost": money(ai_labor_cost),
            "base_contingency": money(base_contingency),
            "ai_contingency": money(ai_contingency),
            "ai_tooling_cost": money(ai_tooling_cost),
            "base_total_cost": money(base_total_cost),
            "ai_total_cost": money(ai_total_cost),
            "cost_difference_ai_minus_base": money(ai_total_cost-base_total_cost),
            "cost_savings": money(base_total_cost-ai_total_cost)
        },
        "hours_and_cost_by_role_seniority": {
            key: {"base_hours": hours(value), "base_labor_cost": money(role_costs[key])}
            for key, value in sorted(role_hours.items())
        },
        "activities": rows
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Motor de estimativa de esforço e custos")
    parser.add_argument("--parameters", default="parameters.json")
    parser.add_argument("--project", default="project_example.json")
    parser.add_argument("--output", default="")
    args = parser.parse_args()
    result = calculate_project(load_json(args.project), load_json(args.parameters))
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
        print(f"Resultado salvo em: {args.output}")
    else:
        print(rendered)


if __name__ == "__main__":
    main()
