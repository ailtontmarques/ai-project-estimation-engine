import copy
import json
import unittest
from pathlib import Path
from engine import calculate_project, pert_hours, validate_allocations

ROOT = Path(__file__).resolve().parents[1]

class EstimationEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parameters = json.loads((ROOT / "parameters.json").read_text(encoding="utf-8"))
        cls.project = json.loads((ROOT / "project_example.json").read_text(encoding="utf-8"))

    def test_pert_standard_formula(self):
        activity = {"id": "x", "optimistic_hours": 2, "most_likely_hours": 4, "pessimistic_hours": 8}
        self.assertAlmostEqual(pert_hours(activity, self.parameters), 4.3333333333, places=6)

    def test_allocations_must_sum_to_one(self):
        with self.assertRaises(ValueError):
            validate_allocations({"desenvolvimento": {"pleno": 0.8}}, "atividade teste")

    def test_project_has_activities_and_positive_hours(self):
        result = calculate_project(self.project, self.parameters)
        self.assertGreater(result["summary"]["activity_count"], 0)
        self.assertGreater(result["summary"]["base_hours"], 0)
        self.assertGreater(result["summary"]["base_total_cost"], 0)

    def test_ai_scenario_uses_review_rework_and_tooling_cost(self):
        result = calculate_project(self.project, self.parameters)
        summary = result["summary"]
        self.assertGreater(summary["ai_tooling_cost"], 0)
        self.assertAlmostEqual(
            summary["ai_hours"],
            summary["base_hours"] * (
                1 - self.parameters["ai"]["eligible_share_default"] * self.parameters["ai"]["reduction_rate_default"]
                + self.parameters["ai"]["review_hours_per_base_hour_default"]
                + self.parameters["ai"]["rework_hours_per_base_hour_default"]
            ),
            delta=0.02
        )

    def test_custom_ai_assumptions_are_respected(self):
        project = copy.deepcopy(self.project)
        activity = project["features"][0]["tasks"][0]["activities"][0]
        activity["ai"] = {
            "eligible_share": 0,
            "reduction_rate": 0.5,
            "review_hours_per_base_hour": 0,
            "rework_hours_per_base_hour": 0
        }
        result = calculate_project(project, self.parameters)
        row = next(x for x in result["activities"] if x["activity_id"] == activity["id"])
        self.assertAlmostEqual(row["ai_hours"], row["base_hours"], places=6)

    def test_invalid_optimistic_most_likely_pessimistic_order(self):
        activity = {"id": "x", "optimistic_hours": 5, "most_likely_hours": 4, "pessimistic_hours": 8}
        with self.assertRaises(ValueError):
            pert_hours(activity, self.parameters)

    def test_costs_are_nonnegative_and_summary_matches_activity_sum(self):
        result = calculate_project(self.project, self.parameters)
        activity_sum = round(sum(a["base_labor_cost"] for a in result["activities"]), 2)
        self.assertEqual(activity_sum, result["summary"]["base_labor_cost"])
        self.assertGreaterEqual(result["summary"]["ai_total_cost"], 0)

if __name__ == "__main__":
    unittest.main()
