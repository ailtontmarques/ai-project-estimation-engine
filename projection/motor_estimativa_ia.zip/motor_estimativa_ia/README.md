# Motor inicial de estimativa de esforço e custos com/sem IA

Versão demonstrativa em Python puro, sem banco de dados e sem dependências externas.

## Conteúdo
- `engine.py`: motor determinístico de cálculo.
- `parameters.json`: taxas horárias, parâmetros PERT, premissas de IA e contingência.
- `project_example.json`: projeto fictício dividido em funcionalidades, tarefas e atividades.
- `tests/test_engine.py`: testes automatizados.
- `requirements.txt`: vazio por opção; biblioteca padrão do Python é suficiente.

## Requisitos
Python 3.10 ou superior.

## Executar o cálculo
Na pasta do projeto:

```bash
python engine.py
```

Ou informe arquivos e grave o resultado:

```bash
python engine.py --parameters parameters.json --project project_example.json --output resultado.json
```

## Executar os testes

```bash
python -m unittest discover -s tests -v
```

## Como o cálculo funciona

### Estimativa base (sem IA)
Para cada atividade, usando horas otimistas (O), mais prováveis (M) e pessimistas (P):

`H_base = (O + 4*M + P) / 6`

Os pesos são configuráveis em `parameters.json`.

### Cenário com IA
`H_AI = H_base * (1 - a*r) + H_base*v + H_base*t`

Onde:
- `a`: fração do trabalho elegível para assistência de IA;
- `r`: redução estimada na fração elegível;
- `v`: horas de revisão por hora-base;
- `t`: horas de retrabalho por hora-base.

Os valores podem ser definidos globalmente em `parameters.json` ou sobrescritos por atividade com um objeto `ai` no JSON do projeto. A economia pode ser negativa: o modelo não presume que IA sempre reduz esforço.

### Custos
Cada atividade distribui 100% das horas entre papéis e senioridades. O custo de mão de obra é a soma de `horas alocadas * taxa horária`. As taxas são hipóteses ilustrativas, não referências de mercado.

- Sem IA: mão de obra + contingência.
- Com IA: mão de obra + contingência + custo de ferramentas de IA configurado para o projeto.

A contingência é mostrada separadamente e não representa uma previsão estatística. Custos de licenças, nuvem, impostos, gestão e outros itens não estão incluídos, salvo o custo fixo de ferramentas de IA explicitamente configurado.

## Estrutura dos dados
Cada funcionalidade contém tarefas; cada tarefa contém atividades. Cada atividade tem:
- horas otimistas, mais prováveis e pessimistas;
- alocação por papel e senioridade, com frações que somam 1.0;
- opcionalmente, parâmetros específicos de IA.

Papéis e senioridades devem existir em `parameters.json`.

## Limitações intencionais desta primeira versão
- Não há interface gráfica, banco de dados, login ou histórico de versões.
- Os parâmetros são ilustrativos e devem ser calibrados com especialistas antes de uso comercial.
- Não há inferência automática de requisitos por LLM; o motor apenas calcula os dados estruturados.
- A comparação é um cenário de planejamento, não uma garantia de produtividade ou economia.
- O custo de ferramentas de IA é fixo por projeto nesta versão simples.
